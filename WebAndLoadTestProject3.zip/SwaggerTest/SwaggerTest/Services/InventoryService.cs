﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SwaggerTest.Services
{
    public class InventoryServices : IInventoryServices
    {
        private readonly Dictionary<string, InventoryItem> _inventoryItems;
        public InventoryServices()
        {
            _inventoryItems = new Dictionary<string, InventoryItem>();
        }
        public InventoryItem AddInventoryItem(InventoryItem item)
        {
            _inventoryItems.Add(item.ItemName, item);
            return item;
        }

        public Dictionary<string, InventoryItem> GetInventoryItems()
        {
            return _inventoryItems;
        }
        public InventoryItem FindInventoryItem(int id)
        {
            var s =  _inventoryItems.Where( t => t.Value.Id == id).SingleOrDefault();
            return s.Value;
        }
    }
}
