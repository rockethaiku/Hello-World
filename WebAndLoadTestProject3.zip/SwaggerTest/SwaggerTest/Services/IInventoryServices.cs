﻿using System.Collections.Generic;

namespace SwaggerTest.Services
{
    public interface IInventoryServices
    {
        InventoryItem AddInventoryItem(InventoryItem item);
         Dictionary<string, InventoryItem> GetInventoryItems();
        InventoryItem FindInventoryItem(int id);
    }
}